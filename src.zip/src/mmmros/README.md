# mmmros - ROS Integration for the Multipurpose Mobile Manipulator
[Read the documentation here](https://github.com/Choitek/mmmros-docs)

Clone this repository into your catkin workspace and `catkin_make` to start developing on the ROS platform for the MMM.
